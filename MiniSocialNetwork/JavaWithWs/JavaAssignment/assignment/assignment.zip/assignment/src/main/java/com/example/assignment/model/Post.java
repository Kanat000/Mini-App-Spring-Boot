package com.example.assignment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Post {
    private String Title;
    private String Text;
    private String visible;
}
