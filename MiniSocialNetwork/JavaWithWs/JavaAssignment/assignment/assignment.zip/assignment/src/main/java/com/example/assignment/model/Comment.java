package com.example.assignment.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Comment {
    String text;
    Long user_id;
    Long post_id;

    public Comment() {
    }
}
