package com.example.assignment.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostVisible {
    Long post_id;
    String visible;

    public PostVisible() {
    }
}
